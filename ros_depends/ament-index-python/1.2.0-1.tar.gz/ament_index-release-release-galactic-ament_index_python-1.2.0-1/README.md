# ament_index_python

`ament_index_python` is a python API to access the ament resource index.

See [https://github.com/ament/ament_cmake/blob/master/ament_cmake_core/doc/resource_index.md](https://github.com/ament/ament_cmake/blob/master/ament_cmake_core/doc/resource_index.md)  for documentation on the ament resource index.

## Quality Declaration

See the [Quality Declaration](./QUALITY_DECLARATION.md) for details on the declared Quality Level.
