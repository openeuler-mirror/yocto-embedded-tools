## rcl

Library to support implementation of language specific ROS Client Libraries.

Features are described in detail at [http://docs.ros2.org](http://docs.ros2.org/latest/api/rcl/index.html)

This package claims to be in the **Quality Level 1** category, see the [Quality Declaration](./QUALITY_DECLARATION.md) for more details.
