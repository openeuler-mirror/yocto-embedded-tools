rclpy
=====

rclpy provides the canonical Python API for interacting with ROS 2.

.. toctree::
   :maxdepth: 3

   about
   examples
   api

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
