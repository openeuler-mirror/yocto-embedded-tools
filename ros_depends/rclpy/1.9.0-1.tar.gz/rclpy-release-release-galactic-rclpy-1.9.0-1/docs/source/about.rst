About
=====

The canonical Python API for `ROS 2 <https://docs.ros.org/en/rolling>`_.

*rclpy* is built on the common C-API provided by `rcl <https://github.com/ros2/rcl>`_.

