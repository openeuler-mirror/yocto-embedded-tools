# console_bridge_vendor
CMake shim over the console_bridge library: https://github.com/ros/console_bridge.git

## Quality Declaration

This package claims to be in the **Quality Level 1** category, see the [Quality Declaration](./QUALITY_DECLARATION.md) for more details.
