# `rmw_fastrtps_cpp`

`rmw_fastrtps_dynamic_cpp` implements the ROS middleware interface using eProsima Fast DDS introspection typesupport at run time to decide on the serialization/deserialization mechanism.

For more information see the repository level [README](../README.md)

## Quality Declaration

This package claims to be in the **Quality Level 3** category, see the [Quality Declaration](QUALITY_DECLARATION.md) for more details.
