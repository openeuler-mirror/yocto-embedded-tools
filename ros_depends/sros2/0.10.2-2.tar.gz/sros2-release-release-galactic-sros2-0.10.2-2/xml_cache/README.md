The file 'xml.xsd' was downloaded from http://www.w3.org/2001/03/xml.xsd and is installed
along with the sros2 package so the schema lookup will succeed even without an internet
connection.
