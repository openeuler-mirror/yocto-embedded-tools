# libyaml_vendor
CMake wrapper downloading and building libyaml

## Quality Declaration files

Quality declaration for this package: [libyaml_vendor QD](QUALITY_DECLARATION.md).

Quality declaration of external dependency [libyaml](./libyaml_q_declaration.md).
