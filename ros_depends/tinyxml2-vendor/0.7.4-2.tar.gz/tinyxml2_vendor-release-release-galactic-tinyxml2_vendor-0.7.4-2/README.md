# tinyxml2_vendor
temporary vendor package for tinyxml2
