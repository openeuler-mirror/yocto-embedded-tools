rosdistro
=========

Tools to work with catkinized rosdistro files