^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ament_cmake_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.2 (2021-05-12)
------------------

0.9.1 (2021-01-25)
------------------
* Update package maintainers. (`#11 <https://github.com/ros2/ament_cmake_ros/issues/11>`_)
* Contributors: Michel Hidalgo

0.9.0 (2020-04-17)
------------------

0.8.0 (2019-09-24)
------------------
* 0.8.0
* Add isolated gmock test (`#4 <https://github.com/ros2/ament_cmake_ros/issues/4>`_)
* Contributors: Michael Carroll, Peter Baughman

0.7.0 (2019-04-11)
------------------

0.5.0 (2018-06-18)
------------------

0.4.0 (2017-12-08)
------------------
* Add definition of ROS_PACKAGE_NAME (`#2 <https://github.com/ros2/ament_cmake_ros/issues/2>`_)
* 0.0.3
* 0.0.2
* Export ament_cmake
* add ament_cmake_ros providing the option BUILD_SHARED_LIBS defaulting to ON
* Contributors: Dirk Thomas, Esteve Fernandez, dhood
