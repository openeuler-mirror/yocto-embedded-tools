To launch this test open two different consoles:

In the first one launch: ./DDSZeroCopyExample publisher (or DDSZeroCopyExample.exe publisher on windows).
In the second one: ./DDSZeroCopyExample subscriber (or DDSZeroCopyExample.exe subscriber on windows).

