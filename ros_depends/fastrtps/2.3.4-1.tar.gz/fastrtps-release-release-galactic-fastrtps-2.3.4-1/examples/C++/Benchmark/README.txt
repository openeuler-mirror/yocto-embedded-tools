To launch this test open two different consoles:

In the first one launch: './Benchmark publisher tcp' or './Benchmark publisher udp' (or Benchmark.exe publisher on windows).
In the second one: './Benchmark subscriber tcp' or './Benchmark subscriber udp'



