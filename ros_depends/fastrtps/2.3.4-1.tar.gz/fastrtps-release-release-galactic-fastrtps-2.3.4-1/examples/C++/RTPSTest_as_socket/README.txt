To launch this test open two different consoles:

In the first one launch: ./RTPSTest_as_socket reader (or RTPSTest_as_socket.exe reader on windows).
In the second one: ./RTPSTest_as_socket writer (or RTPSTest_as_socket.exe writer on windows).
