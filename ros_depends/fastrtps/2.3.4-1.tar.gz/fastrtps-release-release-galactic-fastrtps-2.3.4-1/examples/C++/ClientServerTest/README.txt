To launch this test open two different consoles:

In the first one launch: './ClientServerTest server' (or ClientServerTest.exe server on windows).
In the second one: './ClientServerTest client' (or ClientServerTest.exe client on windows).
