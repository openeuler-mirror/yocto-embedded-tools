osrf_pycommon
=============

Commonly needed Python modules, used by Python software developed at OSRF
