The ``terminal_color`` Module
=============================

.. automodule:: osrf_pycommon.terminal_color
    :members:
