# spdlog_vendor
CMake shim over the spdlog library: https://github.com/gabime/spdlog.git

## Quality Declaration files

Quality declaration for this package: [spdlog_vendor QD](QUALITY_DECLARATION.md).

Quality declaration for spdlog: [spdlog QD](SPDLOG_QUALITY_DECLARATION.md).
