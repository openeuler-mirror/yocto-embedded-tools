# rpyutils
Various utility types and functions for Python

## API

- Context manager for adding DLLs to the Windows search path.
  Only applies to Python 3.8 or newer:
    - `add_dll_directories_from_env`
