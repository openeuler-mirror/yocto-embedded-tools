^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rpyutils
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.0 (2020-09-11)
------------------
* Create a shared function for importing c libraries (`#4 <https://github.com/ros2/rpyutils/issues/4>`_)
* Add pytest.ini so local tests don't display warning (`#3 <https://github.com/ros2/rpyutils/issues/3>`_)
* Contributors: Chris Lalancette, Emerson Knapp

0.1.0 (2020-05-18)
------------------
* Add context manager for adding DLL directories to the search path (`#2 <https://github.com/ros2/rpyutils/issues/2>`_)
* Add package files and linter tests (`#1 <https://github.com/ros2/rpyutils/issues/1>`_)
* Contributors: Jacob Perron
