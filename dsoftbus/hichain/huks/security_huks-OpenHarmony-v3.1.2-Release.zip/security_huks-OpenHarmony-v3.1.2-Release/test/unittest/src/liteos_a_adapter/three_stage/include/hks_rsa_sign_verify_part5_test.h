/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef HKS_RSA_SIGN_VERIFY_PART5_TEST_H
#define HKS_RSA_SIGN_VERIFY_PART5_TEST_H
namespace Unittest::RsaSignVerify {
int HksRsaSignVerifyPart5Test041(void);

int HksRsaSignVerifyPart5Test042(void);

int HksRsaSignVerifyPart5Test043(void);

int HksRsaSignVerifyPart5Test044(void);

int HksRsaSignVerifyPart5Test045(void);

int HksRsaSignVerifyPart5Test046(void);

int HksRsaSignVerifyPart5Test047(void);

int HksRsaSignVerifyPart5Test048(void);

int HksRsaSignVerifyPart5Test049(void);

int HksRsaSignVerifyPart5Test050(void);
}
#endif // HKS_RSA_SIGN_VERIFY_PART5_TEST_H